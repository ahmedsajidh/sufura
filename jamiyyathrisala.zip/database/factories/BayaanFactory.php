<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Bayaan;
use Faker\Generator as Faker;

$factory->define(Bayaan::class, function (Faker $faker) {
    return [
        //
    ];
});
