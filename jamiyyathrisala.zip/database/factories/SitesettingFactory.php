<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sitesetting;
use Faker\Generator as Faker;

$factory->define(Sitesetting::class, function (Faker $faker) {
    return [
        //
    ];
});
