<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="icon" href="/storage/sitesetting/<?php echo e($sitesettings[0]->logo); ?>" sizes="32x32" type="image/png">
    <title> <?php echo e($sitesettings[0]->sitetitle); ?></title>

    <link rel="stylesheet" href="/frontend/assets/css/icons.min.css">
    <link rel="stylesheet" href="/frontend/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/frontend/assets/css/animate.min.css">
    <link rel="stylesheet" href="/frontend/assets/css/fancybox.min.css">
    <link rel="stylesheet" href="/frontend/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/frontend/assets/css/jquery.circliful.css">
    <link rel="stylesheet" href="/frontend/assets/css/style.css">
    <link rel="stylesheet" href="/frontend/assets/css/rtl.css">
    <link rel="stylesheet" href="/frontend/assets/css/responsive.css">

    <!-- Color Scheme -->
    <link rel="stylesheet" href="/frontend/assets/css/colors/color3.css" /><!-- Color -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<main>
    <div class="pageloader-wrap">
        <div class="loader">
            <div class="loader__bar"></div>
            <div class="loader__bar"></div>
            <div class="loader__bar"></div>
            <div class="loader__bar"></div>
            <div class="loader__bar"></div>
            <div class="loader__ball"></div>
        </div>
    </div><!-- Pageloader Wrap -->
    <header class="style2">
        <div class="container">
            <div class="logo"><a href="<?php echo e(URL::to('/')); ?>" title="Logo"><img src="/storage/sitesetting/<?php echo e($sitesettings[0]->logo); ?>" alt="logo3.png"></a></div>
            <nav>
                <div>


                    <ul>
                        <li class="thaana1"><a href="<?php echo e(URL::to('/')); ?>" title="">ފުރަތަމަ ސަފްހާ</a></li>
                        <li class=" thaana1"><a href="<?php echo e(Route('all-bayaan')); ?>" title="">ނޫސްބަޔާން</a></li>
                        <li><a class="thaana1" href="<?php echo e(URL::to('/allpost')); ?>" title=""> ލިޔުން/ޙަބަރު</a></li>
                        <li><a class="thaana1" href="<?php echo e(URL::to('/allvideos')); ?>" title="">ވީޑިއޯ</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </header><!-- Header -->
    <div class="rspn-hdr">
        
            
                
                
                
                
            
        
        <div class="lg-mn">
            <div class="logo"><a href="index.html" title="Logo"><img src="/storage/sitesetting/<?php echo e($sitesettings[0]->footerlogo); ?>" alt="logo2.png"></a></div>
            <div class="rspn-cnt">
                <span><i class="fa fa-envelope thm-clr"></i><a href="#" title=""><?php echo e($sitesettings[0]->email); ?></a></span>
                <span><i class="fa fa-phone thm-clr"></i><?php echo e($sitesettings[0]->number); ?></span>
            </div>
            <span class="rspn-mnu-btn"><i class="fa fa-list-ul"></i></span>
        </div>
        <div class="rsnp-mnu">
            <span class="rspn-mnu-cls"><i class="fa fa-times"></i></span>
            <ul class="thaana">
                <li class=" thaana"><a href="<?php echo e(URL::to('/')); ?>" title=""> ފިރަތަމަ ސަޕްހާ</a></li>
                <li class="thaana"><a href="<?php echo e(Route('all-bayaan')); ?>" title="">ނޫސްބަޔާން</a></li>
                <li><a class="thaana" href="<?php echo e(URL::to('/allpost')); ?>" title=""> ލިޔުން/ޙަބަރު</a></li>
                <li><a class="thaana" href="<?php echo e(URL::to('/allvideos')); ?>" title="">ވީޑިއޯ</a></li>
            </ul>
        </div><!-- Responsive Menu -->
    </div><!-- Responsive Header -->
    <div class="header-search">
        <span class="srch-cls-btn brd-rd5"><i class="fa fa-times"></i></span>
        <form>
            <input type="text" placeholder="Search here...">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>
    </div><!-- Header Search -->

        <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <div class="gap top-spac70 drk-bg2 remove-bottom">
            <div class="container">
                <div class="footer-data">
                    <div class="row">
                        <div class="col-md-4 col-sm-12 col-lg-4">
                            <div class="wdgt-box style2">
                                <div class="logo"><a href="index.html" title="Logo"><img src="/storage/sitesetting/<?php echo e($sitesettings[0]->footerlogo); ?>" alt="logo2.png"></a></div>
                                <p class="thaana"><?php echo e($sitesettings[0]->sitedescription); ?></p>
                                <p class="thaana">ފޯން: <?php echo e($sitesettings[0]->number); ?></p>
                                <p class="thaana">އީމެއިލް: <?php echo e($sitesettings[0]->email); ?> </p>
                            </div>
                        </div>
                        <div class="col-md-8 col-sm-12 col-lg-8">
                            <div class="row">
                                <div class="col-md-4 col-sm-4 col-lg-4">
                                    <div class="wdgt-box">

                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4 col-lg-4">
                                    <div class="wdgt-box">

                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4 col-lg-4">
                                    <div class="wdgt-box">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Footer Data -->
                <div class="bottom-bar">
                    <p class="thaana"> <?php echo e($sitesettings[0]->footercopyright); ?></p>
                    <div class="scl">
                        <a href="<?php echo e($sitesettings[0]->fburl); ?>" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                    </div>
                </div><!-- Bottom Bar -->
            </div>
        </div>
    </footer>
</main><!-- Main Wrapper -->

<script src="/frontend/assets/js/jquery.min.js"></script>
<script src="/frontend/assets/js/bootstrap.min.js"></script>
<script src="/frontend/assets/js/downCount.js"></script>
<script src="/frontend/assets/js/fancybox.min.js"></script>
<script src="/frontend/assets/js/isotope.pkgd.min.js"></script>
<script src="/frontend/assets/js/perfectscrollbar.min.js"></script>
<script src="/frontend/assets/js/owl.carousel.min.js"></script>
<script src="/frontend/assets/js/jquery.circliful.min.js"></script>
<script src="/frontend/assets/js/custom-scripts.js"></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\jamiyyathrisala\resources\views/frontend/layout.blade.php ENDPATH**/ ?>