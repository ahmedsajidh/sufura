<?php $__env->startSection('metatag'); ?>
    <meta property="og:title" content="<?php echo e($post->title); ?>" />
    <meta property="og:url" content="https://www.jamiyathrisaalaa.com/" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="pt-5 mt-5 animate__animated animate__fadeIn">

        <div class="container  pt-5">
            <div class="row">
                <div class="col-md-3">

                </div>
                <div class="col-md-6">
                    <h2 style="line-height: 60px;" class="thaana text-center pb-5"><?php echo e($post->title); ?></h2>
                    
                    <hr>
                    <p class="thaana rtl"> <?php echo e($date->dhivehidate($post->created_at)); ?></p>
                    <hr>
                    <div class="utheemfont" style="line-height: 40px; font-size: larger;">
                        <iframe src="/storage/file/<?php echo e($post->file); ?>" width="100%" height="800px">
                        </iframe>
                    </div>
                </div>
                <div class="col-md-3">

                </div>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\jamiyyathrisala\resources\views/frontend/bayaan/single.blade.php ENDPATH**/ ?>