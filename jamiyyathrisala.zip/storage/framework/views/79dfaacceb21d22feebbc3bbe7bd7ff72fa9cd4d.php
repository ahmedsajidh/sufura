<?php $__env->startSection('content'); ?>

    <section>
        <div class="gap">
            <div class="container">
                <div class="col-md-8 col-sm-6 col-lg-8">
                    <div class="evnt-box">
                        <div class="evnt-thmb">
                            <iframe src="/storage/file/<?php echo e($post->file); ?>" width="100%" height="800px">
                            </iframe>
                        </div>

                    </div>
                    <h1 class="thaana1" style="text-align: right;"><?php echo e($post->title); ?></h1>
                </div>
            </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jamiyyathrisala\resources\views/frontend/bayaan/single.blade.php ENDPATH**/ ?>