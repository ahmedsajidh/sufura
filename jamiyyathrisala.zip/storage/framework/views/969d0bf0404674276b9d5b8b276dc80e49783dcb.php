<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta property="og:description"
          content="Non profitable Organisation in H Dh Nolhivaran" />
    <meta name="keywords" content="Islamic-asociacion nolhivaran" />
    <meta property="og:site_name" content="JAMIYYATH RISAALAA" />
    <?php echo $__env->yieldContent('metatag'); ?>
    <link rel="icon" href="/storage/sitesetting/<?php echo e($sitesettings[0]->logo); ?>" sizes="32x32" type="image/png">
    <title> <?php echo e($sitesettings[0]->sitetitle); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/icons.min.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<main>
    <header class="style2">
        <div class="container">

            <nav class="navbar navbar-expand-lg  navbar-light bg-light fixed-top thaana" style="font-size: 13px;">
                <div class="container-fluid ">
                    <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>" title="Logo"><img src="/storage/sitesetting/<?php echo e($sitesettings[0]->logo); ?>" alt="logo3.png"></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav  mb-2 mb-lg-0  pr-5 pl-5 justify-content-center" >
                            <li class="nav-item text-center pr-2">
                                <a class="nav-link active " aria-current="page" href="<?php echo e(URL::to('/')); ?>">ފުރަތަމަ ސަފްހާ</a>
                            </li>
                            <li class="nav-item text-center pr-2">
                                <a class="nav-link" href="<?php echo e(route('habaru')); ?>">ޙަބަރު</a>
                            </li>
                            <li class="nav-item text-center pr-2">
                                <a class="nav-link" href="<?php echo e(route('report')); ?>">ރިޕޯޓް</a>
                            </li>
                            <li class="nav-item text-center pr-2">
                                <a class="nav-link" href="<?php echo e(Route('bayan')); ?>">ބަޔާން</a>
                            </li>
                            <li class="nav-item text-center pr-2">
                                <a class="nav-link" href="<?php echo e(route('event')); ?>">ޕްރޮގްރާމް</a>
                            </li>
                            <li class="nav-item text-center pr-2">
                                <a class="nav-link" href="#">ފޮޓޯ</a>
                            </li>
                            <li class="nav-item text-center pr-2">
                                <a class="nav-link" href="<?php echo e(route('videos')); ?>">ވީޑިއޯ</a>
                            </li>
                        </ul>
                        <center><a class="btn btn-sm btn-primary mb-2" href="<?php echo e(route('form')); ?>">އިވެންޓް ފޯމް</a></center>
                        
                            
                            
                        
                    </div>
                </div>
            </nav>
        </div>
    </header><!-- Header -->

        <?php echo $__env->yieldContent('content'); ?>

    <section id="subfooter" class="pt-2 mt-5 animate__animated animate__fadeIn" style=" background-color: #0e4861; ">
        <div class="container" style="padding-right: 5%; padding-left: 5%;">
            <div class="row">
                <div class="col-md-6 mb-4">
                    <p style="color: white;" class=" mb-2 thaana">މިބައިގަ ލާނީ ކޮން އެއްޗެއް</p>

                </div>
                <div class="col-md-6 mb-4">
                    <div class="card h-100 1" style="border: none; ">
                        <div class="card-body " style="background-color: #0e4861;">
                            <h5 class="card-title thaana text-light" >އަޅުގަނޑުމެންނަކީ</h5>
                            <h5><img class="" src="logo.png" ></h5>
                            <p class="utheemfont" style="color: white; font-size: 20px;">މިބައިގަ ލިޔާނީ ކުޑަ ހުލާސާކޮޅެއް ޖަމިއްޔާގެ</p>
                            <div class="">
                                <h4 class="thaana text-light">ފޮލޯކުރައްވާ</h4>
                                <a class="text-center" style="font-size: 50px; color: white;" href="https://www.facebook.com/mudhaaexpress/"><i class="fab fa-facebook"></i></a>
                                <a class="text-center" style="font-size: 50px; color: #fefefe; " href="https://www.facebook.com/mudhaaexpress/"><i class="fab fa-instagram-square"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="animate__animated animate__fadeIn" style="background-color: #0b0b0c">
        <footer class="card-footer">
            <p style="text-align: center; "><small style="color: white;">Copyright © 2020 Jamiyyath Risaalaa. All rights reserved.</small> <small style="color: white;">Crafted with ❤ in Maldives. By <a href="">Sajidh.</a></small></p>
        </footer>
    </section>
</main><!-- Main Wrapper -->
<script src="<?php echo e(asset('/frontend/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/pgb.js')); ?>"></script>
<script src="<?php echo e(asset('/frontend/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.thaana.js')); ?>"></script>
<script type="text/javascript">
    jQuery('.thaana').thaana();
    jQuery('.utheemfont').thaana();
</script>
</body>
</html>
<?php /**PATH D:\projects\jamiyyathrisala\resources\views/frontend/layout.blade.php ENDPATH**/ ?>