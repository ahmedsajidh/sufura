<?php $__env->startSection('header'); ?>

    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>REGITER PAGE</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Admin</a></li>
                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    <li class="breadcrumb-item active">Register</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- /.box -->
    <div class="box container">
        <div class="box-header">
            <h3 class="box-title">Users Register For Event</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Program</th>
                    <th>Phone</th>
                    <th>Adress</th>
                    <th>ID Card</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $registers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($register->fullname); ?></td>
                        <td><?php echo e($register->Event->name); ?></td>
                        <td><?php echo e($register->phone); ?></td>
                        <td><?php echo e($register->address); ?></td>
                        <td><?php echo e($register->idcard); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Program</th>
                    <th>Phone</th>
                    <th>ID Card</th>
                </tr>
                </tfoot>
            </table>
        </div>

    <!-- /.box-body -->
    </div>
    <!-- /.box -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\jamiyyathrisala\resources\views/backend/event/index.blade.php ENDPATH**/ ?>