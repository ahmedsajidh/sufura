<?php $__env->startSection('header'); ?>

    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Site Settings</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Layout</a></li>
                    <li class="breadcrumb-item active">Fixed Layout</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('sitesetting-update',['id'=> $setting->id ])); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="form-group">
                <label for="exampleInputEmail1">Site Title</label>
                <input name="sitetitle" type="text" class="form-control thaana" id="exampleInputEmail1" value="<?php echo e($setting->sitetitle); ?>">
            </div>
        </div>

        <div class="form-group">
            <img style="width: 50px;" src="/storage/sitesetting/<?php echo e($setting->logo); ?>">
            <label for="exampleInputFile">Logo Topbar</label>
            <div class="input-group">
                <div class="custom-file">
                    <input type="file"  name="logo" value="<?php echo e($setting->logo); ?>" >
                </div>
            </div>
        </div>

        <div class="form-group">
            <img style="width: 50px;" src="/storage/sitesetting/<?php echo e($setting->fevicon); ?>">
            <label for="exampleInputFile">Fevicon for browser tab</label>
            <div class="input-group">
                <div class="custom-file">
                    <input type="file"  name="fevicon" value="<?php echo e($setting->fevicon); ?>" >
                </div>
            </div>
        </div>

        <div class="form-group">
            <img style="width: 50px;" src="/storage/sitesetting/<?php echo e($setting->footerlogo); ?>">
            <label for="exampleInputFile">White Logo For Footer</label>
            <div class="input-group">
                <div class="custom-file">
                    <input type="file"  name="footerlogo" value="<?php echo e($setting->footerlogo); ?>" >
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="exampleInputEmail1">Site Description</label>
                <input name="sitedescription" type="text" class="form-control thaana" id="exampleInputEmail1" value="<?php echo e($setting->sitedescription); ?>">
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="exampleInputEmail1">Phone Number</label>
                <input name="number" type="number" class="form-control thaana" id="exampleInputEmail1" value="<?php echo e($setting->number); ?>">
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="exampleInputEmail1">Email</label>
                <input name="email" type="email" class="form-control thaana" id="exampleInputEmail1" value="<?php echo e($setting->email); ?>">
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="exampleInputEmail1">Footer Coppy rights</label>
                <input name="footercopyright" type="text" class="form-control thaana" id="exampleInputEmail1" value="<?php echo e($setting->footercopyright); ?>">
            </div>
        </div>

        <div class="form-group">
            <img style="width: 50px;" src="/storage/sitesetting/<?php echo e($setting->help); ?>">
            <label for="exampleInputFile">Ehee Banner</label>
            <div class="input-group">
                <div class="custom-file">
                    <input type="file"  name="help" value="<?php echo e($setting->help); ?>" >
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="form-group">
                <label for="exampleInputEmail1">Facebook URL</label>
                <input name="fburl" type="text" class="form-control thaana" id="exampleInputEmail1" value="<?php echo e($setting->fburl); ?>">
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\jamiyyathrisala\resources\views/backend/sitesetting/index.blade.php ENDPATH**/ ?>