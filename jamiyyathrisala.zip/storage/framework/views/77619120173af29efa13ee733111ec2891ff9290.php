<?php $__env->startSection('header'); ?>

    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Home Page</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Layout</a></li>
                    <li class="breadcrumb-item active">Fixed Layout</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- left column -->
    <div class="col-md-6 offset-6">
        <!-- general form elements -->
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Event</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo e(route('event-update',['id'=> $event->id ])); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="form-group  ">
                        <label for="inputEmail4">Event Title</label>
                        <input name="name" type="text" class="form-control"  placeholder="Category Title" value="<?php echo e($event->name); ?>">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Create</button>
            </form>
        </div>
        <!-- /.box -->



    </div>
    <!--/.col (left) -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\jamiyyathrisala\resources\views/backend/eventcreate/edit.blade.php ENDPATH**/ ?>