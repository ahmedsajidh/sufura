<?php $__env->startSection('content'); ?>

    <section class ="owl-curve-green">

        <div class="gap no-gap">

            <img class="botm-shp shp-img" src="/frontend/assets/images/shp2-1.png" alt="shp2-1.png">

            <div class="featured-area-wrap text-center">


                <div class="featured-area2 owl-carousel">
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="featured-item style2" style="background-image: url(/storage/image/<?php echo e($slide->image); ?>);">
                        <div class="featured-cap">
                            <h1 class="thaana1" style="color: #42af29"><?php echo e($slide->title); ?></h1>
                            <h3 class="thaana" style="font-size: 20px; margin-bottom: 10px;"><?php echo e($slide->secondtitle); ?></h3>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div><!-- Featured Area Wrap -->

        </div>

    </section>

    <section>
        <div class="gap">
            <div class="container">
                <div class="evnt-pry-wrap">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="sec-title">
                                <div class="sec-title-inner">
                                    <h3 class="thaana1">ލިޔުން / ޙަބަރު</h3>
                                </div>
                                <p class="thaana">ޖަމިއްޔަތުއް ރިސާލާގެ ލިޔުންތައް</p>
                            </div>
                            <div class="evnt-wrap remove-ext5">
                                <div class="row mrg20">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div class="evnt-box">
                                            <a href="#">
                                            <div class="evnt-thmb" style="width: 600px;height: 400px;">
                                                    <a href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($post->id); ?>" title=""><img  src="/storage/image/<?php echo e($post->image); ?>" alt="evnt-img1.jpg"></a>
                                            </div>
                                            </a>
                                            <div class="evnt-info">
                                                <a href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($post->id); ?>">
                                                <h4 class="thaana1"><?php echo e($post->title); ?></h4>
                                                </a>
                                                <ul class="pst-mta">
                                                    <li class="thm-clr" style="direction: ltr;"><?php echo e($post->created_at->diffForHumans()); ?></li>
                                                    <li class="thm-clr thaana"><?php echo e($post->author->name); ?></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $allposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6 col-lg-3">
                                        <div class="evnt-box">
                                            <div class="evnt-thmb" style="width: 290px;height: 200px;">
                                                <a href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($allpost->id); ?>" title=""><img src="/storage/image/<?php echo e($allpost->image); ?>" alt="evnt-img1.jpg"></a>
                                            </div>
                                            <div class="evnt-info">
                                                <a href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($allpost->id); ?>">
                                                <h4 class="thaana1"><?php echo e($allpost->title); ?></h4>
                                                </a>
                                                <ul class="pst-mta">
                                                    <li class="thm-clr" style="direction: ltr;"><?php echo e($allpost->created_at->diffForHumans()); ?></li>
                                                    <li class="thm-clr thaana"><?php echo e($allpost->author->name); ?></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div><!-- Events Wrap -->
                        </div>
                    </div>
                </div><!-- Events & Prayer Wrap -->
            </div>
        </div>
    </section>
    <section>
        <div class="gap">
            <div class="container">
                <div class="evnt-pry-wrap">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="sec-title">
                                <div class="sec-title-inner">
                                    <h3 class="thaana1">ވީޑިއޯ</h3>
                                </div>
                                <p class="thaana">ޖަމިޔަތހ ރިސާލާގެ ވީޑިއޯ</p>
                            </div>
                            <div class="evnt-wrap remove-ext5">
                                <div class="row mrg20">
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 col-sm-6 col-lg-12">
                                        <div class="evnt-box">
                                            <div class="evnt-thmb" style="width: 1150px;height: 600px;">
                                                <a href="<?php echo e(URL::to('/post-video/')); ?>/<?php echo e($video->id); ?>" title=""><img src="/storage/video/<?php echo e($video->image); ?>" alt="evnt-img1.jpg"></a>
                                            </div>
                                            <div class="evnt-info">
                                                <h4 class="thaana1"><?php echo e($video->title); ?> </h4>
                                                <ul class="pst-mta">
                                                    <li class="thm-clr"><?php echo e($video->created_at->diffForHumans()); ?></li>
                                                    <li class="thm-clr thaana"><?php echo e($video->author->name); ?> </li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $allvideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allvideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6 col-lg-3">
                                        <div class="evnt-box">
                                            <div class="evnt-thmb">
                                                <a href="<?php echo e(URL::to('/post-video/')); ?>/<?php echo e($allvideo->id); ?>" title=""><img src="/storage/video/<?php echo e($allvideo->image); ?>" alt="evnt-img1.jpg"></a>
                                            </div>
                                            <div class="evnt-info">
                                                <h4 class="thaana1"><?php echo e($allvideo->title); ?></h4>
                                                <ul class="pst-mta">
                                                    <li class="thm-clr"><?php echo e($allvideo->created_at->diffForHumans()); ?></li>
                                                    <li class="thm-clr thaana"><?php echo e($allvideo->author->name); ?></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div><!-- Events Wrap -->
                        </div>
                    </div>
                </div><!-- Events & Prayer Wrap -->
            </div>
        </div>
    </section>
    <section>
        <div class="gap">
            <div class="container">
                <div class="sec-title2 text-center">
                    <div class="sec-title-inner2">
                        <span></span>
                        <h3 class="thaana1">އެހީތެރިވެދިނުމަށް</h3>
                    </div>
                </div>
                <div class="serv-wrap text-center remove-ext3">
                    <div class="row">
                        <div class="col-md-12 col-sm-126 col-lg-12">
                            <div class="srv-box2">
                                <i class=""></i>
                                <div class="srv-info2">
                                    <img  src="/storage/sitesetting/<?php echo e($sitesettings[0]->help); ?>" alt="shp2-1.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Serv Wrap -->

            </div>
        </div>
    </section>


    <section>
        <div class="gap">
            <div class="container">
                <div class="evnt-pry-wrap">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="sec-title">
                                <div class="sec-title-inner">
                                    <h3 class="thaana1">ނޫސްބަޔާން</h3>
                                </div>
                                <p class="thaana">ޖަމިއްޔަތުއް ރިސާލާގެ ފަހުގެ ނޫސްބަޔާން</p>
                            </div>
                            <div class="evnt-wrap remove-ext5">
                                <div class="row mrg20">
                                    <?php $__currentLoopData = $bayaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6 col-lg-3">
                                        <div class="evnt-box">
                                            <div class="evnt-thmb">
                                                <a href="<?php echo e(URL::to('/bayaan/')); ?>/<?php echo e($bayaan->id); ?>" title=""><img src="/storage/image/<?php echo e($bayaan->image); ?>" alt="evnt-img1.jpg"></a>
                                            </div>
                                            <div class="evnt-info">
                                                <h4 class="thaana1"><?php echo e($bayaan->title); ?> </h4>
                                                <ul class="pst-mta">
                                                    <li class="thm-clr"><?php echo e($bayaan->created_at->diffForHumans()); ?></li>
                                                    <li class="thm-clr thaana"><?php echo e($bayaan->author->name); ?></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div><!-- Events Wrap -->
                        </div>
                    </div>
                </div><!-- Events & Prayer Wrap -->
            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jamiyyathrisala\resources\views/frontend/index.blade.php ENDPATH**/ ?>