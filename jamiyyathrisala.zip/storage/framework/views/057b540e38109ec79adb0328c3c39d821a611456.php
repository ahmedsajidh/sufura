<?php $__env->startSection('content'); ?>

    <section>
        <div class="gap">
            <div class="container">
                <div class="evnt-pry-wrap">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="sec-title">
                                <div class="sec-title-inner">
                                    <h3 class="thaana1">ވީޑިއޯ</h3>
                                </div>
                                <p class="thaana">ޖަމިއްޔަތުއް ރިސާލާގެ ފަހުގެ ވީދިއޯ</p>
                            </div>
                            <div class="evnt-wrap remove-ext5">
                                <div class="row mrg20">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6 col-lg-3">
                                        <div class="evnt-box">
                                            <div class="evnt-thmb">
                                                <a href="#" title=""><img src="/storage/image/<?php echo e($post->image); ?>" alt="evnt-img1.jpg"></a>
                                            </div>
                                            <div class="evnt-info">
                                                <h4 class="thaana1"><?php echo e($post->title); ?></h4>
                                                <ul class="pst-mta">
                                                    <li class="thm-clr"><?php echo e($post->created_at->diffForHumans()); ?></li>
                                                    <li class="thm-clr thaana"><?php echo e($post->author->name); ?></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php echo $posts->links();; ?>

                            </div><!-- Events Wrap -->
                        </div>
                    </div>
                </div><!-- Events & Prayer Wrap -->
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jamiyyathrisala\resources\views/frontend/video/all.blade.php ENDPATH**/ ?>