<?php $__env->startSection('content'); ?>

    <section>
        <div class="gap">
            <div class="container">
                <div class="col-md-8 col-sm-6 col-lg-8">
                    <div class="evnt-box">
                        <div class="evnt-thmb">
                            <a href="#" title=""><img src="/storage/image/<?php echo e($post->image); ?>" alt="evnt-img1.jpg"></a>
                        </div>

                    </div>
                    <h1 class="thaana1" style="text-align: right;"><?php echo e($post->title); ?></h1>
                </div>
                <div style="float: right; margin-top: 10px; margin-right: 10px;">
                    <p class="thaana"><span class="thaana1" style="margin-left: 10px;">  ލިޔުނީ:</span> <?php echo e($post->author->name); ?> </p>
                </div>

                <div class="col-md-8 col-sm-6 col-lg-8 paragraa"  >

                  <p style="padding-top: 50px; box-sizing: border-box; margin: 0px 0px 10px; color: #333333; font-family: 'Faseyha', 'Waheedh', Faruma, 'mv iyyu nala', 'mv elaaf normal', 'MV Waheed', 'MV Boli'; font-size: 18px; text-align: justify;">
                      <?php echo $post->body; ?>

                  </p>
                </div>
            </div>

        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jamiyyathrisala\resources\views/frontend/dheeneepost/single.blade.php ENDPATH**/ ?>