<?php $__env->startSection('content'); ?>

    <section>
        <div class="gap">
            <div class="container">
                <div class="col-md-8 col-sm-6 col-lg-8">
                    <div class="evnt-box">
                        <div class="evnt-thmb">
                            <iframe width="1150" height="538" src="https://www.youtube.com/embed/<?php echo e($post->url); ?>"  autoplay="1" rel="0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>

                    </div>
                    <h1 class="thaana1" style="text-align: right;"><?php echo e($post->title); ?></h1>
                </div>
                <div style="float: right; margin-top: 10px; margin-right: 10px;">
                    <p class="thaana"><span class="thaana1" style="margin-left: 10px;">  ލިޔުނީ:</span> <?php echo e($post->author->name); ?> </p>
                </div>

                <div class="col-md-8 col-sm-6 col-lg-8 "  >

                </div>
            </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jamiyyathrisala\resources\views/frontend/video/single.blade.php ENDPATH**/ ?>