<?php $__env->startSection('content'); ?>

    <section class="pt-5 animate__animated animate__fadeIn">
        <div class="container" style="margin-top: 5px;">
            <h1 class=" thaana" style="font-size: 25px;">ރިޕޯޓް</h1>
            <div class="row" style="direction: rtl;">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-lg-3 col-6 pb-2 card-deck" >
                        <div class="card" style="background-color: whitesmoke; " style="direction: rtl !important;">
                            <img class="card-img-right" src="/storage/image/<?php echo e($post->image); ?>">
                            <div class="card-body" style="direction: rtl !important;" >
                                <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ:<?php echo e($post->name); ?>  | <?php echo e($post->created_at); ?></small></p>
                                <h5 class="card-title thaana" style="direction: rtl !important; font-size: 19px; line-height: 2; "><?php echo e($post->title); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo $posts->links();; ?>

        </div>
    </section>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\jamiyyathrisala\resources\views/frontend/dheeneepost/all.blade.php ENDPATH**/ ?>