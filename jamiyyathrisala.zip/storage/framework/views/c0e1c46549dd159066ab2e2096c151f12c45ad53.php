<?php $__env->startSection('metatag'); ?>
    <meta property="og:title" content="Jamiyath Risaalaa" />
    <meta property="og:url" content="https://www.jamiyathrisaalaa.com/" />
    <meta property="og:image" content="https://one-media.sgp1.digitaloceanspaces.com/post/b_7jDZaRpXPbyJS21033PsVIiHl.jpg" />
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="animate__animated animate__fadeIn " style="padding-top: 69px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body backgroundimage">
                            <p class="card-title thaana text-center" style="font-size: larger; color: white !important;">އަޅުގަނޑުމެންނަށް ފައިސާގެ އެހީތެރިކަން ފޯރުކޮށްދޭން ބޭނުންވާ ފަރާތްތަކުން ތިރީގައިވާ އެކައުންޓަށް ފައިސާ ޖަމާކޮށްދެއްވާ</p>
                            <p class="card-title  text-center" style="font-weight: 700; color: white !important;">BML : 7770000028286</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <table class="table thaana text-center rtl">
                <thead>
                <tr >
                    <th > ފަތިސް <p class="utheemfont" style="direction: ltr;"><?php echo e($prayer->Fajr); ?></p></th>
                    <th > އިރުއަރާ<p class="utheemfont" style="direction: ltr;"><?php echo e($prayer->Sunrise); ?></p></th>
                    <th > މެންދުރު<p class="utheemfont" style="direction: ltr;"><?php echo e($prayer->Dhuhr); ?></p></th>
                    <th > އަސްރު<p class="utheemfont" style="direction: ltr;"><?php echo e($prayer->Asr); ?></p></th>
                    <th > އިރުއޮއްސޭ<p class="utheemfont" style="direction: ltr;"><?php echo e($prayer->Maghrib); ?></p></th>
                    <th > އިޝާ<p class="utheemfont" style="direction: ltr;"><?php echo e($prayer->Isha); ?></p></th>
                </tr>
                </thead>
            </table>
        </div>
    </section>
    <section class="pt-5 pb-5 animate__animated animate__fadeIn" style=" background-color: #eceff3; margin-top: 70px;">
        <div class="container">
            <div class="row" style="direction: rtl;">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-4 col-lg-4 pb-2 card-deck" >

                    <div class="card" style="background-color: whitesmoke; " style="direction: rtl !important;">

                        <img class="card-img-right" src="/storage/image/<?php echo e($post->image); ?>">

                        <div class="card-body" style="direction: rtl !important;" >
                            <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ: <?php echo e($post->author->name); ?>  | <?php echo e($date->dhivehidate($post->created_at)); ?></small></p>
                            <p class="badge badge-primary thaana" style="float: left; font-size: 16px;"><?php echo e($post->category->name); ?></p>
                            <hr>
                            <a style="text-decoration: none;" href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($post->id); ?>">  <h5 class="card-title thaana" style="direction: rtl !important; font-size: 19px; line-height: 2;"> <?php echo e($post->title); ?></h5> </a>
                        </div>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <section class="pt-5 animate__animated animate__fadeIn">
        <div class="container" style="margin-top: 5px;">
            <h1 class=" thaana" style="font-size: 25px;">ޙަބަރު</h1>
            <div class="row" style="direction: rtl;">
                <div class="col-md-6 col-lg-6 pb-2 card-deck" >
                    <?php $__currentLoopData = $habarus1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habaru1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="background-color: whitesmoke; " style="direction: rtl !important;">
                        <img class="card-img-right" src="/storage/image/<?php echo e($habaru1->image); ?>">
                        <div class="card-body" style="direction: rtl !important;" >
                            <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ: <?php echo e($habaru1->name); ?> | <?php echo e($date->dhivehidate($habaru1->created_at)); ?></small></p>
                            <hr>
                            <a style="text-decoration: none;" href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($habaru1->id); ?>">  <h5 class="card-title thaana" style="direction: rtl !important; font-size: 25px; line-height: 2;"><?php echo e($habaru1->title); ?></h5></a>
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-3 col-lg-3 col-6 pb-2 ">
                    <?php $__currentLoopData = $habarus2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habaru2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-2 " style="background-color: whitesmoke;">
                        <img class="card-img-right"  src="/storage/image/<?php echo e($habaru2->image); ?>">
                        <div class="card-body" style="direction: rtl !important;">
                            <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ: <?php echo e($habaru2->name); ?> | <?php echo e($date->dhivehidate($habaru2->created_at)); ?></small></p>
                            <a style="text-decoration: none;" href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($habaru2->id); ?>"> <h5 class="card-title  thaana" style="direction: rtl !important; font-size: 15px; line-height: 2;"><?php echo e($habaru2->title); ?></h5></a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-3 col-lg-3 col-6 pb-2 ">
                    <?php $__currentLoopData = $habarus3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habaru3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-2" style="background-color: whitesmoke;">
                            <img class="card-img-right"  src="/storage/image/<?php echo e($habaru3->image); ?>">
                            <div class="card-body" style="direction: rtl !important;">
                                <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ: <?php echo e($habaru3->name); ?> | <?php echo e($date->dhivehidate($habaru3->created_at)); ?></small></p>
                                <a style="text-decoration: none;" href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($habaru3->id); ?>"> <h5 class="card-title  thaana" style="direction: rtl !important; font-size: 15px; line-height: 2;"><?php echo e($habaru3->title); ?></h5></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="pt-5 animate__animated animate__fadeIn">
        <div class="container" style="margin-top: 5px;">
            <h1 class=" thaana" style="font-size: 25px;">ރިޕޯޓް</h1>
            <div class="row" style="direction: rtl;">
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-lg-3 col-6 pb-2 card-deck" >
                    <div class="card" style="background-color: whitesmoke; " style="direction: rtl !important;">
                        <img class="card-img-right" src="/storage/image/<?php echo e($report->image); ?>">
                        <div class="card-body" style="direction: rtl !important;" >
                            <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ:<?php echo e($report->name); ?>  | <?php echo e($date->dhivehidate($report->created_at)); ?></small></p>
                            <a href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($report->id); ?>" title="">
                            <h5 class="card-title thaana" style="direction: rtl !important; font-size: 19px; line-height: 2; "><?php echo e($report->title); ?></h5>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="pt-5 animate__animated animate__fadeIn">
        <div class="container" style="margin-top: 5px;">
            <h1 class=" thaana" style="font-size: 25px;">ވީޑިއޯ</h1>
            <div class="row" style="direction: rtl;">
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 col-lg-12 pb-2 card-deck" >
                    <div class="card" style="background-color: whitesmoke; " style="direction: rtl !important;">
                        <div class="video-thumbnail ">
                            <a href="<?php echo e(URL::to('/post-video/')); ?>/<?php echo e($video->id); ?>" title="">
                            <img class="card-img-right" style="width: 100%; height: 500px;"  src="/storage/video/<?php echo e($video->image); ?>">
                            </a>
                        </div>
                        <div class="card-body" style="direction: rtl !important;" >
                            <p class="card-text update badge badge-pill thaana text-muted"> <small> <?php echo e($date->dhivehidate($video->created_at)); ?></small></p>
                            <hr>
                            <a href="<?php echo e(URL::to('/post-video/')); ?>/<?php echo e($video->id); ?>" title="">
                            <h5 class="card-title thaana" style="direction: rtl !important; font-size: 25px; line-height: 2;"><?php echo e($video->title); ?></h5>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $allvideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allvideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-lg-3 col-6 pb-2 card-deck">
                    <div class="card mb-2" style="background-color: whitesmoke;">
                        <div class="video-thumbnail ">
                            <a href="<?php echo e(URL::to('/post-video/')); ?>/<?php echo e($allvideo->id); ?>" title="">
                            <img class="card-img-right" style="width: 100%;"  src="/storage/video/<?php echo e($allvideo->image); ?>">
                            </a>
                        </div>
                        <div class="card-body" style="direction: rtl !important;">
                            <p class="card-text update badge badge-pill thaana text-muted"> <small><?php echo e($date->dhivehidate($allvideo->created_at)); ?></small></p>
                            <a href="<?php echo e(URL::to('/post-video/')); ?>/<?php echo e($allvideo->id); ?>" title="">
                            <h5 class="card-title  thaana" style="direction: rtl !important; font-size: 15px; line-height: 2;"><?php echo e($allvideo->title); ?></h5>
                            </a>
                        </div>
                    </div>
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <section class="pt-5 animate__animated animate__fadeIn">
        <div class="container" style="margin-top: 5px;">
            <h1 class=" thaana" style="font-size: 25px;">ޕްރޮގްރާމް</h1>
            <div class="row" style="direction: rtl;">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-6 col-6 pb-2 card-deck" >
                        <div class="card" style="background-color: whitesmoke; " style="direction: rtl !important;">
                            <img class="card-img-right" src="/storage/image/<?php echo e($event->image); ?>">
                            <div class="card-body" style="direction: rtl !important;" >
                                <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ:<?php echo e($event->name); ?>  | <?php echo e($date->dhivehidate($event->created_at)); ?></small></p>
                                <a href="<?php echo e(URL::to('/post/')); ?>/<?php echo e($event->id); ?>" title="">
                                <h5 class="card-title thaana" style="direction: rtl !important; font-size: 19px; line-height: 2; "><?php echo e($event->title); ?></h5>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="pt-5 animate__animated animate__fadeIn">
        <div class="container" style="margin-top: 5px;">
            <h1 class=" thaana" style="font-size: 25px;">ބަޔާން</h1>
            <div class="row" style="direction: rtl;">
                <?php $__currentLoopData = $bayaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-lg-3 col-6 pb-2 card-deck" >
                        <div class="card" style="background-color: whitesmoke; " style="direction: rtl !important;">
                            <img class="card-img-right" src="/storage/image/<?php echo e($bayaan->image); ?>">
                            <div class="card-body" style="direction: rtl !important;" >
                                <p class="card-text update badge badge-pill thaana text-muted"> <small>  ލިޔުނީ:<?php echo e($bayaan->name); ?>  | <?php echo e($date->dhivehidate($bayaan->created_at)); ?></small></p>
                                <a href="<?php echo e(URL::to('/bayaan/')); ?>/<?php echo e($bayaan->id); ?>" title="">
                                <h5 class="card-title thaana" style="direction: rtl !important; font-size: 19px; line-height: 2; "><?php echo e($bayaan->title); ?></h5>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\jamiyyathrisala\resources\views/frontend/index.blade.php ENDPATH**/ ?>