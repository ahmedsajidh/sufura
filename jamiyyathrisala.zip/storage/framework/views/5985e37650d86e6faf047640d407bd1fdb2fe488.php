<?php $__env->startSection('metatag'); ?>
    <meta property="og:url" content="https://www.jamiyathrisaalaa.com/" />
    <meta property="og:title" content="<?php echo e($thaana->transliterate($post->title)); ?>" />
    <meta property="og:image" content="/storage/image/<?php echo e($post->image); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="progress-container pt-5 mt-2 fixed-top" style="z-index: 1;">
        <div class="progress-bar" id="pgb"></div>
    </div>
    <section class="pt-5 mt-5 animate__animated animate__fadeIn">

            <div class="container  pt-5">
                <div class="row">
                    <div class="col-md-3">

                    </div>
                    <div class="col-md-6">
                        <h2 style="line-height: 60px;" class="thaana text-center pb-5"><?php echo e($post->title); ?></h2>
                            <a href="#" title=""><img class="card-img" src="/storage/image/<?php echo e($post->image); ?>" alt="evnt-img1.jpg"></a>
                        <hr>
                        <p class="thaana rtl text-muted text-sm">ލިޔުނީ: <?php echo e($post->author->name); ?> || <?php echo e($post->category->name); ?> || <?php echo e($date->dhivehidate($post->created_at)); ?></p>
                        <hr>
                        <div class="utheemfont rtl mt-5 " style="line-height: 40px; font-size: larger;">
                            <?php echo $post->body; ?>

                        </div>
                    </div>
                    <div class="col-md-3">

                    </div>
                </div>
                <div class="row pt-5">
                    <div class="col-md-3">

                    </div>
                    <div class="col-md-6">
                        <h5 class="thaana pb-5">ހިޔާލުފާޅު ކުރުމަށް</h5>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item thaana rtl"><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                            <form action="<?php echo e(route('create-comment')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-row rtl">
                                    <div class="form-group  ">
                                        <input name="username" type="text" class="form-control thaana"  placeholder="ނަން">
                                    </div>
                                </div>
                                <input hidden name="post_id" value="<?php echo e($post->id); ?>">
                                <div class="form-group  ">
                                    <textarea name="comment" type="text" class="form-control utheemfont rtl"  placeholder="ހިޔާލު"></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary thaana">ޕޯސްޓް</button>
                            </form>

                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($post->id == $comment->post_id): ?>
                        <div class="card mt-5 mb-1">
                            <div class="card-body" style="background-color: whitesmoke;">

                                <h5 class="card-title thaana"> <?php echo e($comment->username); ?> </h5>
                                <p class="utheemfont card-text mt-4"><?php echo e($comment->comment); ?></p>

                            </div>
                        </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-md-3">

                    </div>
                </div>
            </div>

    </section>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\jamiyyathrisala\resources\views/frontend/dheeneepost/single.blade.php ENDPATH**/ ?>