<?php

namespace App\Http\Controllers;

use App\Category;
use App\Comment;
use App\Post;
use App\Sitesetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Sajidh\Dhivehidate\Dhivehidate;
use Thaana\Thaana;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = Post::with('author', 'Category')->orderBy('created_at','desc')->paginate(5);
        return view('backend.post.index',compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        return view('backend.post.form',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->hasFile('image')){
            $filenameWithExt = $request->file('image')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('image')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('image')->storeAs('public/image', $fileNameToStore);

        }else{
            $fileNameToStore ='noimage.jpg';

        }

        $post = new Post;

        $post->author_id = $request->author_id;

        $post->title = $request->title;


        $post->body = $request->body;

        $post->category_id = $request->category_id;

        $post->status = $request->status;

        $post->image = $fileNameToStore;

        $save = $post->save();


        return redirect()->route('all-posts');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Post $post)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
        DB::table('posts')->where('id',$id)->delete();

        return redirect()->route('all-posts')->with('message','deleted Successfully');

    }
    public function editPost($id)
    {
        $categories = Category::with('posts')->get();
        $post = Post::with('Category')->find($id);

        return view('backend.post.edit',compact('post','categories'));
    }
    public function updatePost(Request $request, $id)
    {
        if ($request->hasFile('image')){
            $filenameWithExt = $request->file('image')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('image')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('image')->storeAs('public/image', $fileNameToStore);

        }else{
            $fileNameToStore ='noimage.jpg';

        }
        $post = Post::find($id);

        $post->author_id = $request->input('author_id');

        $post->title = $request->input('title');


        $post->body = $request->input('body');

        $post->category_id = $request->input('category_id');

        $post->status = $request->input('status');

        $post->image = $fileNameToStore;

        $save = $post->save();

        return redirect()->route('all-posts')->with('message','Updated Successfully');
    }

    public function siglepost(Request $request, $id)
    {
        $sitesettings = Sitesetting::all();
        $comments  = Comment::with('post')->get();
        $thaana = new Thaana();
        $date = new Dhivehidate();
        $post = Post::where('id',$id)->with('Category','author')->first();
        return view('frontend.dheeneepost.single',compact('post','sitesettings','date','comments','thaana'));
    }

    public function allpost()
    {
        $sitesettings = Sitesetting::all();
        $posts = Post::with('author', 'Category')->orderBy('created_at','desc')->paginate(5);
        return view('frontend.dheeneepost.all',compact('posts','sitesettings'));
    }

}
