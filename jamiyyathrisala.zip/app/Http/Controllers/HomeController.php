<?php

namespace App\Http\Controllers;

use App\Bayaan;
use App\Post;
use App\Sitesetting;
use App\Slider;
use App\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Sajidh\Dhivehidate\Dhivehidate;
use Sajidh\Prayerscraper\Prayer;

class HomeController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $posts = Post::with('category','author')->orderBy('created_at','desc')->limit(3)->get();

        $allposts = Post::with('category','author')->orderBy('created_at','desc')->skip(1)->limit(6)->get();
        $videos = Video::with('category','author')->orderBy('created_at','desc')->limit(1)->get();
        $allvideos = Video::with('category','author')->orderBy('created_at','desc')->skip(1)->limit(4)->get();
        $bayaans = Bayaan::with('category','author')->orderBy('created_at','desc')->limit(4)->get();
        $slides = Slider::all();
        $sitesettings = Sitesetting::all();

        $habarus1 = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->limit('1')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ޙަބަރު')
            ->get();
        $habarus2 = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->skip('1')
            ->limit('2')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ޙަބަރު')
            ->get();
        $habarus3 = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->skip('2')
            ->limit('2')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ޙަބަރު')
            ->get();
        $reports = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->limit('4')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ރިޕޯޓު')
            ->get();

        $events = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->limit('2')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ޕްރޮގްރާމް')
            ->get();
        $date = new Dhivehidate();
        $prayer = new Prayer();
        return view('frontend.index',
            compact
            (
                'posts',
                    'allposts',
                    'videos',
                    'allvideos',
                    'bayaans',
                    'slides',
                    'sitesettings',
                    'habarus1',
                    'habarus2',
                    'habarus3',
                    'reports',
                    'events','date','prayer'
            ));
    }
    public function habaru(){
        $sitesettings = Sitesetting::all();
        $date = new Dhivehidate();
        $habarus = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ޙަބަރު')
            ->get();

        return view('frontend.habaru.index',compact('habarus','sitesettings','date'));
    }
    public function report(){
        $sitesettings = Sitesetting::all();

        $habarus = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->limit('4')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ރިޕޯޓު')
            ->get();

        return view('frontend.report.index',compact('habarus','sitesettings'));
    }
    public function event(){
        $sitesettings = Sitesetting::all();

        $habarus = DB::table('posts')
            ->select('posts.author_id','posts.title','posts.body','posts.image','posts.status','posts.category_id','posts.category_id','posts.id','users.name','posts.created_at')
            ->orderBy('created_at','desc')
            ->join('categories', 'posts.category_id', '=', 'categories.id')
            ->join('users', 'posts.author_id', '=', 'users.id')

            ->where('categories.name', '=','ޕްރޮގްރާމް')
            ->get();

        return view('frontend.event.index',compact('habarus','sitesettings'));
    }
    public function bayaan(){
        $sitesettings = Sitesetting::all();

        $habarus = Bayaan::with('category','author')->orderBy('created_at','desc')->get();

        return view('frontend.bayaan.index',compact('habarus','sitesettings'));
    }

    public function video(){
        $sitesettings = Sitesetting::all();

        $habarus = Video::with('category','author')->orderBy('created_at','desc')->get();

        return view('frontend.video.index',compact('habarus','sitesettings'));
    }
}
