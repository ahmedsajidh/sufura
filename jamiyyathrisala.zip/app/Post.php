<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = [
        'author_id', 'title','body','image','category_id','status',
    ];
    public function  author()
    {
        return $this->belongsTo(User::class);
    }

    public function Category()
    {
        return $this->belongsTo(Category::class);
    }
    public function Comment()
    {
        return $this->hasMany(Comment::class);
    }
}
